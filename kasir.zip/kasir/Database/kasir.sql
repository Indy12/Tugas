-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Jun 2020 pada 12.51
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.3.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbkasir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kasir`
--

CREATE TABLE `kasir` (
  `Nama Barang` varchar(50) NOT NULL,
  `Harga Barang` varchar(50) NOT NULL,
  `Jumlah Beli` varchar(50) NOT NULL,
  `Jumlah Harga` varchar(50) NOT NULL,
  `Jumlah Bayar` varchar(50) NOT NULL,
  `Jumlah Kembalian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kasir`
--

INSERT INTO `kasir` (`Nama Barang`, `Harga Barang`, `Jumlah Beli`, `Jumlah Harga`, `Jumlah Bayar`, `Jumlah Kembalian`) VALUES
('Beras', '25000', '2', '50000', '60000', 'Rp .10000'),
('Gula', '20000', '2', '40000', '50000', 'Rp .10000'),
('Mie', '2500', '1', '2500', '3000', 'Rp .500'),
('Telur', '23000', '2', '46000', '50000', 'Rp .4000');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kasir`
--
ALTER TABLE `kasir`
  ADD PRIMARY KEY (`Nama Barang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
