package Tugas_Struktur_Data;

/**
 *
 * @author Indy
 */
public class Stack {
    private boolean kosong,full;
    private int pos;
    private int max_data=3;
    private int item[]=new int[max_data];
    
    public void Stack(){
        full=false;
        kosong=true;
        pos=0;
    }
    
    public boolean isfull (){
        return (full);
    }
    
    public boolean isKosong (){
        return (kosong);
    }
    
    public void push (int data){
        System.out.print("Hasil : ");
        if(!isfull()){
            item[pos++]=data;
            kosong=false;
            if(pos==max_data){
                full=true;
            }
            System.out.println("Data Sudah Ditambahkan");
        }else{
            System.out.println("Stack Sudah Penuh");
        }
        System.out.println("-----------------------------------------------");
        return; 
    }
    
    public int pop(){
        int x=0;
        System.out.println("Hasil : ");
        if (!isKosong()) {
            x=item[--pos];
            full=false;
            System.out.println("Data yang di Pop adalah "+item[pos]);
            System.out.println("Keterangan : ");
            item[pos]=0;
            if(pos==0){
                kosong=true;
                System.out.println("Stack Kosong");
            }else{
                System.out.println("Data sudah di ambil");
            }
        }else{
            System.out.println("Stack Masih Kosong : \n");
        }
        System.out.println("------------------------------------------------");
        return(x); 
    }
    
    public void display(){
        System.out.println("Isi stuck adalah");
        for (int i = 0; i < pos; i++) {
            System.out.println("Node"+(1+i)+" : "+item[i]+"");
        }
        System.out.println("-------------------------------------------------");
        System.out.println("\n");     
    }
}
