package Tugas_Struktur_Data;
import java.util.*;
/**
 *
 * @author Indy
 */
public class Main {

    public static void main(String[] args) {
        int pilihan;
        int data;
        Stack result = new Stack();
        do{
            System.out.println("1.Push");
            System.out.println("2.Pop Item");
            System.out.println("3.Lihat Isi Data");
            System.out.println("0.Keluar");
            System.out.println("Masukkan Pilihan : ");
            Scanner input=new Scanner(System.in);
            pilihan=input.nextInt();
            if (pilihan==1) {
                System.out.println("Data yang ditambahkan : ");
                data=input.nextInt();
                result.push(data);
            }else if(pilihan==2){
                result.pop();
            }else if (pilihan==3) {
                result.display();
            }else if (pilihan==0) {
                System.exit(0);
            }else{
                System.out.println("Pilihan Tidak Ada");
            }
        }while(pilihan !=0);
    }
    
}
